import serial
import csv
from tqdm import tqdm
import pandas as pd
import numpy as np
from sklearn.preprocessing import MinMaxScaler
from tensorflow import keras

import os
clear = lambda: os.system('cls')

# set up the serial line
ser = serial.Serial('COM3', 9600)

classes = ['Clean', 'Temprature', 'Vibrational']

model = keras.models.load_model('test_rigging.h5')
while True:
    data = []
    
    for i in range(2):
        my_list = []
        b = ser.readline()         # read a byte string
        string_n = b.decode()  # decode byte string into Unicode
        string = string_n.rstrip() 
        
        string = string.split(',')
        for j in range(len(string)):
            x = float(string[j])
            my_list.append(x)
         # remove \n and \r
        #flt = float(string)        # convert string to float
        data.append(my_list)
  
    
    
    # for i in tqdm(range(2)):
    #     temp = []
    #     for j in range(6):
    #         b = ser.readline()         # read a byte string
    #         string_n = b.decode()  # decode byte string into Unicode
    #         string = string_n.rstrip()  # remove \n and \r
    #         #flt = float(string)        # convert string to float
    #         #print(i)
    #         temp.append(string)           # add to the end of data list
    #     data.append(temp)
    #   #  print(data)
    #     # demonstrate prediction

    data = np.array(data)
    
   # print(data)

    data = data.reshape(data.shape[0],data.shape[1],1)
    #print(data.shape)
    #print(data.shape)
    #x_input, y_input = split_sequence(data, n_steps)
    #x_input = x_input.reshape((test.shape[0], n_steps, n_features))
    yhat = np.argmax(model.predict(data), axis=-1)
    # plot baseline and predictions
    print(classes[yhat[0]])

ser.close()

